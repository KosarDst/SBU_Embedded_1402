/*
 * File: Embedded_Ex3_types.h
 *
 * Code generated for Simulink model 'Embedded_Ex3'.
 *
 * Model version                  : 1.8
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Mon Jun  5 21:01:07 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Embedded_Ex3_types_h_
#define RTW_HEADER_Embedded_Ex3_types_h_

/* Model Code Variants */

/* Forward declaration for rtModel */
typedef struct tag_RTM_Embedded_Ex3_T RT_MODEL_Embedded_Ex3_T;

#endif                                 /* RTW_HEADER_Embedded_Ex3_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
