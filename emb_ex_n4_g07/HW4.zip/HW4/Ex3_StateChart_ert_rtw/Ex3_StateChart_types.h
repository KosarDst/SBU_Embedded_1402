/*
 * File: Ex3_StateChart_types.h
 *
 * Code generated for Simulink model 'Ex3_StateChart'.
 *
 * Model version                  : 1.8
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Sun Apr 23 00:07:18 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Ex3_StateChart_types_h_
#define RTW_HEADER_Ex3_StateChart_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_Ex3_StateChart_T RT_MODEL_Ex3_StateChart_T;

#endif                                 /* RTW_HEADER_Ex3_StateChart_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
